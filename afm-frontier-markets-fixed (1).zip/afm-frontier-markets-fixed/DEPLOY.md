# Déploiement AFM FrontierPay sur Northflank — gratuit au départ, pensé pour évoluer

Ce guide déploie la version actuelle (backend + ledger en partie double + frontend
vitrine intégré) sur le plan gratuit de Northflank, avec une architecture qui n'a
**rien à réécrire** le jour où tu dois scaler — seulement des curseurs à monter.

## Pourquoi ça peut évoluer sans réécriture

Deux choix déjà faits dans le code rendent la montée en charge simple plus tard,
plutôt qu'un chantier :
- **Aucun état en mémoire du service** : les verrous d'idempotence et les compteurs
  de conformité vivent dans Redis, pas dans une variable Python locale. Tu peux donc
  passer de 1 à N réplicas du service à tout moment, sans changement de code —
  chaque réplica partage le même état via Redis.
- **Le ledger et les transactions vivent en base Postgres**, jamais en mémoire —
  scaler horizontalement le service ne casse ni la comptabilité ni l'idempotence.

Autrement dit : ce que tu montes aujourd'hui en gratuit (1 instance, plan
`nf-compute-10`) est la MÊME architecture que tu feras tourner à 5 instances plus
tard — tu changes des paramètres dans le dashboard, pas le code.

## Avant de commencer — vérifie les limites actuelles de ton compte

Les chiffres exacts du free tier Northflank évoluent régulièrement (à ce jour :
environ **2 services + 1 base de données**). Ce template déploie **1 service
applicatif + 2 addons (Postgres + Redis)**. Si ton compte n'autorise qu'1 seule
base de données gratuite :
- Garde l'addon **Postgres** (c'est lui qui porte le ledger — non négociable)
- Auto-héberge **Redis** comme un simple service Docker (`redis:7-alpine`, sans
  persistance) à la place de l'addon managé — il compte alors comme ton 2ᵉ
  "service" plutôt que comme une "base de données"

Vérifie dans **Northflank → Billing → Plans** avant de lancer le template.

---

## Étape 1 — Pousser le code sur GitHub

Le dépôt local (`afm-frontier-markets-fixed/`) a déjà 3 commits prêts. Il ne
manque que le remote :

```bash
cd afm-frontier-markets-fixed
git remote add origin https://github.com/<ton-org>/afm-frontier-markets-fixed.git
git push -u origin main
```

(Si le dépôt GitHub n'existe pas encore : crée-le vide sur
[github.com/new](https://github.com/new), **sans** cocher "Add a README" pour
éviter un conflit avec l'historique déjà présent.)

## Étape 2 — Créer le template sur Northflank

1. Connecte-toi sur [northflank.com](https://northflank.com) (carte bancaire
   demandée à l'inscription, non débitée tant que tu restes sur le free tier)
2. Menu **Templates** → **Create template**
3. Onglet **Code** de l'éditeur → colle le contenu de `northflank.json`
4. Renseigne les arguments en haut du template :
   - `REPO_URL` → l'URL de ton dépôt GitHub (étape 1)
   - `REPO_BRANCH` → `main`
   - `ALLOWED_ORIGINS` → ton domaine, ou laisse tel quel si pas encore défini
5. **Run template** — Northflank crée le projet, les 2 addons, le groupe de
   secrets et le service applicatif dans l'ordre

## Étape 3 — Lier les identifiants des addons au service (manuel, volontaire)

Northflank ne câble jamais automatiquement les identifiants d'un addon dans le
JSON du template — sécurité contre la fuite d'identifiants dans un fichier
versionné :

1. **Postgres** → onglet **Connect** de l'addon `afm-postgres` → copie la chaîne
   de connexion. **Northflank donne un préfixe `postgresql://`, mais
   `config/database.py` attend `postgresql+asyncpg://`** — remplace le préfixe
   avant de coller la valeur.
2. **Redis** → onglet **Connect** de l'addon `afm-redis` → copie la chaîne
   `redis://` telle quelle.
3. Va sur le service `afm-api-gateway` → **Environment** → ajoute :
   - `DATABASE_URL` = `postgresql+asyncpg://...`
   - `REDIS_URL` = `redis://...`
4. **Redeploy** pour que les nouvelles variables soient prises en compte.

## Étape 4 — Vérifier le déploiement

```bash
curl https://<url-fournie-par-northflank>/health
# {"status":"healthy","timestamp":"..."}

curl https://<url>/
# doit renvoyer le vitrine (HTML), pas du JSON

curl -X POST https://<url>/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@mel-ib.cm","password":"S3curePass!"}'
# doit renvoyer un access_token
```

Si `register` renvoie un token, la chaîne Postgres + Redis + ledger + app est
correctement câblée de bout en bout — c'est le même test qui a validé cette
version en local avant livraison.

## Étape 5 — Variables PSP (optionnel, pour sortir du mode simulation)

Le service tourne en mode simulation tant qu'aucune clé PSP n'est configurée
(comportement volontaire et documenté dans `payment_hub/psp_router.py` — jamais
un faux positif silencieux). Pour activer de vrais paiements, ajoute dans le
groupe de secrets `afm-app-secrets` : `KORA_API_KEY`, `KORA_SECRET_KEY`,
`FINCRA_API_KEY`, `FINCRA_SECRET_KEY`, etc. (voir `.env.example`).

---

## Faire évoluer le déploiement, étape par étape

Rien ci-dessous n'exige de toucher au code — uniquement le dashboard Northflank.

### 1. Premier signe de charge : monter le plan de calcul
`nf-compute-10` (gratuit) → `nf-compute-20`/`nf-compute-50` sur le service
`afm-api-gateway` et sur l'addon Postgres si les requêtes ralentissent. Un seul
curseur dans **Service → Resources**.

### 2. Plusieurs utilisateurs simultanés : passer à plusieurs réplicas
**Service → Scaling → Instances** : passe de 1 à N. Comme rien n'est gardé en
mémoire locale (voir plus haut), aucune donnée n'est perdue ni dupliquée en
répartissant le trafic entre réplicas — le verrou Redis et la contrainte
`UNIQUE` en base continuent de protéger l'idempotence entre toutes les instances.

### 3. Autoscaling automatique
**Service → Scaling → Autoscaling** : définir un nombre min/max de réplicas et
un seuil (CPU ou requêtes/seconde). Northflank ajoute/retire des instances tout
seul — aucune configuration applicative supplémentaire nécessaire.

### 4. Redis auto-hébergé → Redis managé
Si tu as démarré avec un Redis auto-hébergé (faute de 2ᵉ base de données
gratuite), migre vers l'addon Redis managé de Northflank dès que le budget le
permet : recopie `REDIS_URL`, redeploy, supprime l'ancien service Redis.
Aucune ligne de code à changer.

### 5. Domaine personnalisé
**Service → Networking → Custom domain** : ajoute `app.africafrontiermarkets.com`
(ou équivalent), Northflank gère le certificat TLS automatiquement.

### 6. Environnements séparés (staging avant prod)
Duplique le projet Northflank (**Project → Clone**) pour obtenir un environnement
de staging isolé avec sa propre base — utile avant d'activer de vraies clés PSP
en production.

### 7. Déploiement continu
Déjà actif par défaut : le service est lié au dépôt GitHub (`vcsData` dans
`northflank.json`) — chaque `git push` sur `main` redéclenche automatiquement un
build et un déploiement. Aucune configuration CI/CD supplémentaire nécessaire
pour commencer.

### 8. Observabilité, quand le volume le justifie
**Project → Observability** : logs centralisés et métriques de base sont déjà
inclus même en free tier. Les alertes (Slack/email sur erreur 5xx, latence)
s'ajoutent en un clic quand le service devient critique pour de vrais paiements.

---

# Un agent pour piloter le déploiement

## Option A — Le CLI officiel Northflank (le plus fiable)
```bash
npm install -g @northflank/cli
northflank login
northflank push template ./northflank.json --project afm-frontierpay
```
Maintenu directement par Northflank, sans dépendance à un service tiers.
Recommandé pour tout ce qui touche à la prod d'une fintech.

## Option B — Un agent conversationnel (Claude Code) branché sur Northflank
Northflank publie un connecteur MCP (via [Composio](https://composio.dev/toolkits/northflank))
pour piloter Northflank **depuis Claude Code en langage naturel** — déployer,
consulter des logs, scaler une instance — sans quitter le terminal :

1. Dans Claude Code : `claude mcp add-json northflank '{"type":"http","url":"<url-session-composio>"}'`
   (URL de session obtenue en te connectant sur composio.dev/toolkits/northflank
   et en autorisant l'accès OAuth à ton compte Northflank)
2. Ensuite : *"déploie le dernier commit sur afm-api-gateway"* ou *"passe le
   service à 2 réplicas"*

**Recommandation** : déploiement initial (étapes 1 à 4) via CLI officiel ou
dashboard web — plus rapide à auditer, trace claire. Réserve l'agent
conversationnel aux opérations répétitives une fois l'infra en place.
