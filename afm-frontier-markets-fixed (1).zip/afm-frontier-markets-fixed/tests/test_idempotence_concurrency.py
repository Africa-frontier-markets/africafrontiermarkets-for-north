"""
Test de concurrence sur l'idempotence — répond directement au test pratique
n°1 exigé par l'audit :

  Test              | Scénario                          | Résultat attendu
  Idempotence       | 100 requêtes identiques en parallèle | Un seul effet financier

Contrairement à un test unitaire qui appelle le code séquentiellement, celui-
ci lance N requêtes RÉELLEMENT concurrentes (asyncio.gather) contre le
service pour vérifier que le verrou Redis + la contrainte UNIQUE en base
tiennent sous contention réelle, pas seulement en théorie.
"""
from decimal import Decimal
from uuid import uuid4

import asyncio
import pytest
from sqlalchemy import select

from config.exceptions import ConflictError
from payment_hub.models import Transaction, User
from payment_hub.payment_service import payment_service


async def test_concurrent_identical_requests_produce_one_effect(db_session, make_user):
    """
    100 appels identiques (même utilisateur, même montant, même devise,
    même clé d'idempotence cliente) lancés en parallèle : une seule
    Transaction doit exister en base à la fin, les 99 autres doivent avoir
    échoué avec ConflictError (verrou Redis pris ou contrainte UNIQUE en
    base), jamais avec une erreur non gérée.
    """
    user = await make_user()
    await db_session.commit()

    idempotency_key = f"concurrency-test-{uuid4()}"
    n_concurrent = 100

    async def _attempt():
        try:
            tx = await payment_service.process_payment(
                user_id=user.id,
                amount=Decimal("2500"),
                currency="XOF",
                method="mobile_money",
                phone_number="+22501234567",
                idempotency_key=idempotency_key,
            )
            return ("success", tx.id)
        except ConflictError:
            return ("conflict", None)
        except Exception as e:
            return ("unexpected_error", str(e))

    results = await asyncio.gather(*[_attempt() for _ in range(n_concurrent)])

    successes = [r for r in results if r[0] == "success"]
    conflicts = [r for r in results if r[0] == "conflict"]
    unexpected = [r for r in results if r[0] == "unexpected_error"]

    assert unexpected == [], f"Des appels ont échoué avec une erreur non gérée : {unexpected}"
    assert len(successes) == 1, f"Un seul appel doit réussir, {len(successes)} ont réussi"
    assert len(conflicts) == n_concurrent - 1

    # Vérification indépendante directement en base : une seule ligne pour
    # cette clé d'idempotence, quel que soit ce que le code applicatif a
    # rapporté (ne pas se fier uniquement aux valeurs de retour en mémoire).
    from config.database import AsyncSessionLocal
    async with AsyncSessionLocal() as verify_session:
        result = await verify_session.execute(
            select(Transaction).where(Transaction.user_id == user.id)
        )
        transactions = result.scalars().all()
        assert len(transactions) == 1, (
            f"Une seule transaction doit exister en base pour cette clé "
            f"d'idempotence, {len(transactions)} trouvées — double effet financier détecté"
        )
