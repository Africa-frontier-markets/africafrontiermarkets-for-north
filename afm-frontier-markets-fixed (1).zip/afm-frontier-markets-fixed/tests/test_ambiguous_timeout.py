"""
Test du scénario "timeout ambigu" — répond directement au test pratique
n°2 exigé par l'audit :

  Test           | Scénario                              | Résultat attendu
  Timeout ambigu | PSP traite mais ne répond pas          | Aucun double payout

On simule un timeout réseau vers Kora (mock de httpx) et on vérifie que :
1. La transaction n'est JAMAIS marquée COMPLETED sans confirmation positive
2. La transaction n'est JAMAIS marquée FAILED non plus (ce qui autoriserait
   un appelant naïf à réessayer et risquer un double paiement)
3. Elle finit dans l'état AMBIGUOUS, explicitement en attente de
   réconciliation
4. Aucune écriture de ledger n'est postée pour une transaction ambiguë
   (pas de mouvement de fonds tant que l'issue réelle n'est pas confirmée)
"""
from decimal import Decimal
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import httpx
import pytest
from sqlalchemy import select

from config.config import get_settings
from payment_hub.models import PaymentStatus
from payment_hub.ledger_models import LedgerEntry
from payment_hub.payment_service import payment_service


async def test_timeout_never_resolves_to_completed_or_failed_silently(db_session, make_user, monkeypatch):
    user = await make_user()
    await db_session.commit()

    # On sort du court-circuit de simulation dev de _call_kora
    # (`if settings.is_development or not settings.kora_secret_key`) en
    # mutant les VRAIS settings (singleton lru_cache), pour exercer le
    # vrai chemin de gestion d'erreur réseau plutôt que le mode simulé.
    # monkeypatch restaure les valeurs d'origine automatiquement à la fin
    # du test — pas besoin de mock global de get_settings, qui casserait
    # d'autres attributs (ex: redis_url) utilisés ailleurs dans le service.
    real_settings = get_settings()
    monkeypatch.setattr(real_settings, "environment", "staging")
    monkeypatch.setattr(real_settings, "kora_secret_key", "fake-key-to-bypass-simulation")

    mock_client = AsyncMock()
    mock_client.post.side_effect = httpx.TimeoutException("Connection timed out after 30s")
    monkeypatch.setattr(payment_service, "_get_http_client", AsyncMock(return_value=mock_client))

    transaction = await payment_service.process_payment(
        user_id=user.id,
        amount=Decimal("7500"),
        currency="XOF",
        method="mobile_money",
        phone_number="+22501234567",
        idempotency_key=f"timeout-test-{uuid4()}",
    )

    assert transaction.status == PaymentStatus.AMBIGUOUS, (
        f"Un timeout doit résulter en AMBIGUOUS, jamais en résolution "
        f"automatique — statut obtenu : {transaction.status}"
    )
    assert transaction.status != PaymentStatus.COMPLETED
    assert transaction.status != PaymentStatus.FAILED

    # Aucune écriture de ledger ne doit exister pour cette transaction :
    # pas de mouvement de fonds tant que l'issue n'est pas confirmée.
    from config.database import AsyncSessionLocal
    async with AsyncSessionLocal() as verify_session:
        result = await verify_session.execute(
            select(LedgerEntry).where(LedgerEntry.transaction_id == transaction.id)
        )
        entries = result.scalars().all()
        assert entries == [], (
            "Aucune écriture comptable ne doit être postée pour une "
            "transaction dont l'issue réelle est inconnue"
        )


async def test_definite_psp_error_response_is_failed_not_ambiguous(db_session, make_user, monkeypatch):
    """
    Contre-exemple : une réponse HTTP d'erreur EXPLICITE du PSP (le PSP a
    répondu, il a refusé) doit être un échec définitif (FAILED), pas
    ambigu — contrairement à un timeout. La distinction entre "on ne sait
    pas" et "le PSP a dit non" est le cœur de la correction demandée par
    l'audit.
    """
    user = await make_user()
    await db_session.commit()

    real_settings = get_settings()
    monkeypatch.setattr(real_settings, "environment", "staging")
    monkeypatch.setattr(real_settings, "kora_secret_key", "fake-key-to-bypass-simulation")

    fake_request = httpx.Request("POST", "https://api.korapay.com/merchant/api/v1/charges/mobile-money")
    fake_response = httpx.Response(402, request=fake_request)

    mock_response = MagicMock()
    mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
        "402 Payment Required", request=fake_request, response=fake_response
    )
    mock_client = AsyncMock()
    mock_client.post.return_value = mock_response
    monkeypatch.setattr(payment_service, "_get_http_client", AsyncMock(return_value=mock_client))

    transaction = await payment_service.process_payment(
        user_id=user.id,
        amount=Decimal("3000"),
        currency="XOF",
        method="mobile_money",
        phone_number="+22501234567",
        idempotency_key=f"definite-failure-test-{uuid4()}",
    )

    assert transaction.status == PaymentStatus.FAILED
    assert transaction.status != PaymentStatus.AMBIGUOUS
