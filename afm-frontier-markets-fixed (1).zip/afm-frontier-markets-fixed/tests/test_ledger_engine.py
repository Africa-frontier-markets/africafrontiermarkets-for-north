"""
Tests du ledger en partie double — répond directement au test pratique
n°6 exigé par l'audit ("Montre-moi le schéma du ledger, les écritures
débit/crédit et la clôture") et à la conclusion générale : "Ledger : aucune
preuve suffisante d'un ledger en partie double".

Ces tests nécessitent une vraie base Postgres (DATABASE_URL) — voir
conftest.py pour la configuration de session de test.
"""
from decimal import Decimal
from uuid import uuid4

import pytest

from config.exceptions import LedgerError
from payment_hub.ledger_engine import ledger_engine
from payment_hub.ledger_models import LedgerDirection


async def test_balanced_journal_is_accepted(db_session, make_user):
    user = await make_user()
    transit = await ledger_engine._get_or_create_system_account(db_session, "psp_transit", "XOF")
    user_account = await ledger_engine.get_or_create_user_account(db_session, user.id, "XOF")

    journal_id = await ledger_engine.post_journal(
        db_session,
        entries=[
            {"account": transit, "direction": LedgerDirection.DEBIT, "amount": Decimal("1000"), "currency": "XOF"},
            {"account": user_account, "direction": LedgerDirection.CREDIT, "amount": Decimal("1000"), "currency": "XOF"},
        ],
        description="test balanced journal",
    )
    await db_session.commit()
    assert journal_id is not None


async def test_unbalanced_journal_is_rejected(db_session, make_user):
    """
    Le cœur de la correction : le moteur DOIT refuser d'écrire un journal
    dont les débits et les crédits ne s'équilibrent pas exactement. C'est
    l'invariant que l'audit reproche à l'architecture actuelle de ne pas
    démontrer.
    """
    user = await make_user()
    transit = await ledger_engine._get_or_create_system_account(db_session, "psp_transit", "XOF")
    user_account = await ledger_engine.get_or_create_user_account(db_session, user.id, "XOF")

    with pytest.raises(LedgerError):
        await ledger_engine.post_journal(
            db_session,
            entries=[
                {"account": transit, "direction": LedgerDirection.DEBIT, "amount": Decimal("1000"), "currency": "XOF"},
                {"account": user_account, "direction": LedgerDirection.CREDIT, "amount": Decimal("900"), "currency": "XOF"},
            ],
            description="test unbalanced journal — must be rejected",
        )


async def test_negative_or_zero_amount_rejected(db_session, make_user):
    user = await make_user()
    transit = await ledger_engine._get_or_create_system_account(db_session, "psp_transit", "XOF")
    user_account = await ledger_engine.get_or_create_user_account(db_session, user.id, "XOF")

    with pytest.raises(LedgerError):
        await ledger_engine.post_journal(
            db_session,
            entries=[
                {"account": transit, "direction": LedgerDirection.DEBIT, "amount": Decimal("0"), "currency": "XOF"},
                {"account": user_account, "direction": LedgerDirection.CREDIT, "amount": Decimal("0"), "currency": "XOF"},
            ],
        )


async def test_post_payment_completed_balances_transit_payable_and_revenue(db_session, make_user):
    """
    Vérifie l'écriture standard d'un paiement complété :
    DEBIT transit = amount ; CREDIT payable = net ; CREDIT revenue = fee.
    """
    user = await make_user()
    amount = Decimal("10000")
    fee = Decimal("25.00")
    net = amount - fee

    journal_id = await ledger_engine.post_payment_completed(
        db_session,
        user_id=user.id,
        amount=amount,
        fee_amount=fee,
        net_amount=net,
        currency="XOF",
        transaction_id=None,
    )
    await db_session.commit()

    transit = await ledger_engine._get_or_create_system_account(db_session, "psp_transit", "XOF")
    revenue = await ledger_engine._get_or_create_system_account(db_session, "afm_revenue", "XOF")
    user_account = await ledger_engine.get_or_create_user_account(db_session, user.id, "XOF")

    assert await ledger_engine.get_balance(db_session, transit.id) == amount
    assert await ledger_engine.get_balance(db_session, user_account.id) == net
    assert await ledger_engine.get_balance(db_session, revenue.id) == fee
    assert journal_id is not None


async def test_fee_split_mismatch_rejected(db_session, make_user):
    """
    Si net + fee != amount (ex: bug d'arrondi en amont), post_payment_completed
    doit refuser plutôt que de poster un ledger déséquilibré.
    """
    user = await make_user()
    with pytest.raises(LedgerError):
        await ledger_engine.post_payment_completed(
            db_session,
            user_id=user.id,
            amount=Decimal("10000"),
            fee_amount=Decimal("25.00"),
            net_amount=Decimal("9974.00"),  # devrait être 9975.00
            currency="XOF",
            transaction_id=uuid4(),
        )


async def test_reversal_never_mutates_original_journal(db_session, make_user):
    """
    Une contrepassation (refund/chargeback) doit poster un NOUVEAU journal
    inversé, sans jamais modifier les écritures d'origine — c'est ce qui
    rend le journal auditable (cf. audit section 4.2).
    """
    user = await make_user()
    original_journal_id = await ledger_engine.post_payment_completed(
        db_session,
        user_id=user.id,
        amount=Decimal("5000"),
        fee_amount=Decimal("12.50"),
        net_amount=Decimal("4987.50"),
        currency="XOF",
        transaction_id=None,
    )
    await db_session.commit()

    reversal_journal_id = await ledger_engine.reverse_journal(
        db_session, original_journal_id, reason="refund demandé par le client"
    )
    await db_session.commit()

    assert reversal_journal_id != original_journal_id

    transit = await ledger_engine._get_or_create_system_account(db_session, "psp_transit", "XOF")
    # Après complétion (+5000 débit) puis contrepassation (+5000 crédit),
    # le solde net du compte transit doit revenir à zéro — sans qu'aucune
    # écriture existante n'ait été modifiée (on l'a juste équilibrée par une nouvelle).
    assert await ledger_engine.get_balance(db_session, transit.id) == Decimal("0")
