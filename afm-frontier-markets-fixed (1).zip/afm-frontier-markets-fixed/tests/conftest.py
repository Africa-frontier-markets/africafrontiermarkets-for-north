"""
Configuration pytest partagée — utilise une VRAIE base Postgres (via
DATABASE_URL) et un VRAI Redis (via REDIS_URL), pas de mocks de la couche
DB. C'est une réponse directe à l'audit : "19 tests annoncés mais
insuffisants ; absence initiale reconnue" — ces tests s'exécutent contre
de vraies dépendances pour avoir une valeur probante.
"""
import asyncio
import pytest
import pytest_asyncio

from config.database import Base, engine, AsyncSessionLocal
# Importer tous les modules de modèles pour qu'ils s'enregistrent sur
# Base.metadata avant tout create_all — sinon les clés étrangères vers
# 'users'/'transactions' échouent avec NoReferencedTableError dès qu'un
# fichier de test n'importe que ledger_models sans passer par payment_hub.models.
import payment_hub.models  # noqa: F401
import payment_hub.ledger_models  # noqa: F401


@pytest_asyncio.fixture(scope="function")
async def db_session():
    """
    Crée toutes les tables si besoin, fournit une session, et NETTOIE les
    tables ledger/transactions/webhook après chaque test pour que les
    tests soient indépendants les uns des autres (pas de fixture globale
    partagée qui masquerait un vrai bug d'isolation).
    """
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with AsyncSessionLocal() as session:
        yield session
        await session.rollback()

    async with engine.begin() as conn:
        await conn.execute(__import__("sqlalchemy").text(
            "TRUNCATE TABLE ledger_entries, ledger_accounts, reconciliation_discrepancies, "
            "webhook_events, transactions, users RESTART IDENTITY CASCADE"
        ))


@pytest_asyncio.fixture(scope="function")
async def redis_client():
    import redis.asyncio as aioredis
    from config.config import get_settings
    settings = get_settings()
    client = aioredis.from_url(settings.redis_url, decode_responses=True)
    yield client
    await client.flushdb()
    await client.close()


@pytest_asyncio.fixture
async def make_user(db_session):
    """
    Crée un vrai utilisateur en base. Nécessaire car
    ledger_accounts.owner_id porte une contrainte de clé étrangère vers
    users.id — un compte de ledger ne peut pas référencer un utilisateur
    qui n'existe pas (intégrité référentielle voulue, pas assouplie pour
    les tests).
    """
    from payment_hub.models import User

    async def _make(email: str | None = None):
        import uuid as _uuid
        user = User(
            email=email or f"test-{_uuid.uuid4().hex[:8]}@afm-test.local",
            hashed_password="test-hash-not-a-real-password",
        )
        db_session.add(user)
        await db_session.flush()
        return user

    return _make
