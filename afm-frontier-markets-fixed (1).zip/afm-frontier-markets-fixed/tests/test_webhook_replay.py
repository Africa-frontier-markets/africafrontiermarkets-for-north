"""
Test de rejeu de webhook — répond directement au test pratique n°5 exigé
par l'audit :

  Test           | Scénario                    | Résultat attendu
  Webhook replay | Rejeu d'un ancien événement | Rejet ou déduplication

Avant cette correction, un webhook vérifié (signature correcte) ne
produisait aucun effet ET aucune trace : un rejeu était donc accepté
indéfiniment sans jamais être détecté comme un doublon.
"""
import hashlib
import hmac
import json
from decimal import Decimal
from uuid import uuid4

import pytest
from sqlalchemy import select

from config.config import get_settings
from payment_hub.models import PaymentStatus, Transaction, WebhookEvent
from payment_hub.payment_service import payment_service


def _sign(payload: bytes, secret: str) -> str:
    return hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()


async def test_webhook_replay_is_deduplicated_not_reprocessed(db_session, make_user, monkeypatch):
    user = await make_user()
    await db_session.commit()

    # Transaction existante en attente de confirmation (comme après un
    # premier appel PSP réel avant que le webhook de confirmation n'arrive).
    reference = f"webhook-test-{uuid4()}"
    transaction = Transaction(
        idempotency_key=reference,
        user_id=user.id,
        psp="kora",
        amount=Decimal("4000"),
        currency="XOF",
        fee_amount=Decimal("10.00"),
        fee_currency="XOF",
        net_amount=Decimal("3990.00"),
        status=PaymentStatus.PENDING,
    )
    db_session.add(transaction)
    await db_session.commit()

    real_settings = get_settings()
    monkeypatch.setattr(real_settings, "kora_webhook_secret", "test-webhook-secret")

    payload_dict = {
        "event": "charge.success",
        "event_id": f"evt_{uuid4()}",
        "data": {"reference": reference, "status": "success"},
    }
    payload = json.dumps(payload_dict).encode()
    signature = _sign(payload, "test-webhook-secret")

    # Premier appel : doit être traité et résoudre la transaction.
    result_1 = await payment_service.process_webhook("kora", payload, signature)
    assert result_1["status"] == "processed"

    from config.database import AsyncSessionLocal
    async with AsyncSessionLocal() as verify_session:
        result = await verify_session.execute(select(Transaction).where(Transaction.id == transaction.id))
        refreshed = result.scalar_one()
        assert refreshed.status == PaymentStatus.COMPLETED

    # Rejeu EXACT du même événement (même payload, même signature) : doit
    # être détecté comme doublon et ne PAS être retraité.
    result_2 = await payment_service.process_webhook("kora", payload, signature)
    assert result_2["status"] == "duplicate_ignored"

    async with AsyncSessionLocal() as verify_session:
        result = await verify_session.execute(
            select(WebhookEvent).where(WebhookEvent.psp == "kora", WebhookEvent.dedup_key == payload_dict["event_id"])
        )
        events = result.scalars().all()
        assert len(events) == 1, "Un seul WebhookEvent doit exister pour cet event_id, même après rejeu"


async def test_webhook_invalid_signature_is_rejected(monkeypatch):
    real_settings = get_settings()
    monkeypatch.setattr(real_settings, "kora_webhook_secret", "test-webhook-secret")

    payload = json.dumps({"event": "charge.success", "data": {"reference": "whatever"}}).encode()

    from config.exceptions import PaymentError
    with pytest.raises(PaymentError):
        await payment_service.process_webhook("kora", payload, "signature-invalide")
