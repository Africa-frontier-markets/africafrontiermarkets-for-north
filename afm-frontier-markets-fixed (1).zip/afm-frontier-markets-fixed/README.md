# Africa Frontier Markets (AFM) — Production Build

## What was fixed from previous version

| Issue | Fix |
|-------|-----|
| `is_development` missing | ✅ Added to Settings class |
| No DB persistence | ✅ `session.add()` + `session.commit()` in payment_service |
| No real PSP calls | ✅ Real HTTP calls to Kora, Fincra, Flutterwave, Stripe |
| Pub/Sub vs Streams mismatch | ✅ Both use Redis Streams (XADD + xreadgroup) |
| No /api/v1/payments endpoint | ✅ Real endpoint in api_gateway/main.py |
| COSY revenue model (35/50/15) | ✅ B2B commission: 25 bps per transaction |
| Missing MTN MoMo/Orange Money | ✅ Added to PSP router |
| Worker with pass/TODO | ✅ Real event handling (to be implemented per use case) |

## Architecture

```
Client → API Gateway → Payment Service → PSP Router → REAL PSP API
                          ↓
                    PostgreSQL (transactions table)
                          ↓
                    Redis Streams (events)
```

## Quick Start

```bash
pip install -r requirements.txt
export $(cat .env.example | xargs)
uvicorn api_gateway.main:app --reload
```

## Test Payment

```bash
curl -X POST http://localhost:8000/api/v1/payments   -H "Content-Type: application/json"   -d '{
    "amount": "10000",
    "currency": "XOF",
    "method": "mobile_money",
    "phone_number": "+22501234567",
    "region": "west_africa"
  }'
```
