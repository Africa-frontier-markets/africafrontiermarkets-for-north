"""
AFM Revenue Engine — B2B Transaction Fee Model

NOT COSY. This is pure fintech:
- Commission per transaction: 25 bps (0.25%)
- Min fee: $0.50
- Max fee: $50.00
- No ads, no creator split, no platform split.
"""

from decimal import Decimal, ROUND_HALF_UP
from dataclasses import dataclass

from config.config import get_settings
from config.logging_config import configure_logging

logger = configure_logging()


@dataclass
class FeeBreakdown:
    gross_amount: Decimal
    afm_fee: Decimal
    afm_fee_bps: int
    net_amount: Decimal
    psp_fee: Decimal  # Estimated PSP fee
    psp_fee_bps: int
    total_cost_to_merchant: Decimal


class AFMRevenueEngine:
    """
    B2B Revenue Engine for AFM.

    AFM charges a commission on every transaction processed.
    This is NOT a creator economy split — it's a pure payment processing fee.
    """

    # AFM commission
    AFM_COMMISSION_BPS = 25  # 0.25%
    AFM_MIN_FEE_USD = Decimal("0.50")
    AFM_MAX_FEE_USD = Decimal("50.00")

    # CORRECTION (bug découvert en construisant le ledger en partie double) :
    # AFM_MIN_FEE_USD/AFM_MAX_FEE_USD sont libellés en USD, mais l'ancien
    # code les comparait directement à un montant de frais calculé sur
    # `amount` — qui est dans la devise LOCALE de la transaction (XOF, XAF,
    # NGN...). Pour une transaction de 5 000 XOF, le fee brut (12.50 dans
    # les "unités" XOF) était comparé à un plancher de 0.50 et un plafond
    # de 50.00 comme s'ils étaient dans la même unité — alors que 0.50 USD
    # ≈ 300 XOF et 50 USD ≈ 30 000 XOF. Le clamp ne voulait dimensionnellement
    # rien dire.
    #
    # Correctif honnête tant qu'aucun moteur FX temps réel n'existe dans ce
    # projet (contrairement à la V38, ce dépôt n'a pas repris fx_engine.py) :
    # une table de taux indicatifs, explicitement documentée comme
    # approximative, sert à convertir les bornes USD dans la devise de la
    # transaction avant le clamp. Ces taux DOIVENT être remplacés par un
    # fournisseur réel (XE, OpenExchangeRates, taux BEAC/BCEAO officiel)
    # avant toute mise en production — voir le TODO ci-dessous.
    # Taux approximatifs (unités de devise locale pour 1 USD), juillet 2026 :
    APPROX_USD_RATES = {
        "USD": Decimal("1"),
        "EUR": Decimal("0.92"),
        "GBP": Decimal("0.79"),
        "XOF": Decimal("600"),
        "XAF": Decimal("600"),
        "NGN": Decimal("1550"),
        "KES": Decimal("129"),
        "GHS": Decimal("15.5"),
        "ZAR": Decimal("18"),
    }

    # Estimated PSP fees (for margin calculation)
    PSP_FEE_ESTIMATES = {
        "kora": 15,        # 0.15%
        "fincra": 20,      # 0.20%
        "flutterwave": 14, # 0.14% + 1.4% for cards
        "stripe": 29,      # 2.9% + $0.30
        "mtn_momo": 10,    # 0.10%
        "orange_money": 10, # 0.10%
    }

    def __init__(self):
        settings = get_settings()
        self.commission_bps = int(settings.afm_commission_bps)
        self.min_fee = settings.afm_min_fee_usd
        self.max_fee = settings.afm_max_fee_usd

    def _fee_bounds_in_currency(self, currency: str) -> tuple[Decimal, Decimal]:
        """
        Convertit AFM_MIN_FEE_USD / AFM_MAX_FEE_USD dans la devise de la
        transaction. TODO production : remplacer APPROX_USD_RATES par un
        appel à un fournisseur de taux réel avec cache court (cf. le
        correctif déjà appliqué sur fx_engine.py dans la V38).
        """
        rate = self.APPROX_USD_RATES.get(currency.upper())
        if rate is None:
            # Devise non couverte par la table indicative : ne pas deviner un
            # taux, refuser plutôt que produire une borne silencieusement fausse.
            raise ValueError(f"No approximate USD rate configured for currency {currency}")
        return (self.min_fee * rate, self.max_fee * rate)

    def calculate_fee(self, amount: Decimal, currency: str = "USD", psp: str = "kora") -> FeeBreakdown:
        """
        Calculate AFM fee for a transaction.

        Args:
            amount: Transaction amount
            currency: Transaction currency
            psp: PSP used for the transaction

        Returns:
            FeeBreakdown with all fee components
        """
        quantize = Decimal("0.01")
        min_fee_local, max_fee_local = self._fee_bounds_in_currency(currency)

        # AFM commission
        afm_fee = (amount * Decimal(self.commission_bps) / Decimal("10000"))
        afm_fee = max(afm_fee, min_fee_local)
        afm_fee = min(afm_fee, max_fee_local)
        afm_fee = afm_fee.quantize(quantize, rounding=ROUND_HALF_UP)

        # Net amount after AFM fee
        net_amount = amount - afm_fee

        # Estimated PSP fee
        psp_fee_bps = self.PSP_FEE_ESTIMATES.get(psp.lower(), 20)
        psp_fee = (amount * Decimal(psp_fee_bps) / Decimal("10000")).quantize(quantize)

        # Total cost to merchant
        total_cost = afm_fee + psp_fee

        logger.info(
            "Fee calculated",
            amount=str(amount),
            currency=currency,
            afm_fee=str(afm_fee),
            psp_fee=str(psp_fee),
            net=str(net_amount),
        )

        return FeeBreakdown(
            gross_amount=amount.quantize(quantize),
            afm_fee=afm_fee,
            afm_fee_bps=self.commission_bps,
            net_amount=net_amount.quantize(quantize),
            psp_fee=psp_fee,
            psp_fee_bps=psp_fee_bps,
            total_cost_to_merchant=total_cost.quantize(quantize),
        )

    def calculate_monthly_revenue(self, transaction_volume: Decimal, avg_transaction_size: Decimal) -> dict:
        """
        Estimate monthly revenue based on volume.

        Args:
            transaction_volume: Number of transactions per month
            avg_transaction_size: Average transaction amount in USD
        """
        total_volume = transaction_volume * avg_transaction_size

        # AFM revenue
        afm_revenue = (total_volume * Decimal(self.commission_bps) / Decimal("10000"))

        # Cap at max fee per transaction
        max_revenue = transaction_volume * self.max_fee
        afm_revenue = min(afm_revenue, max_revenue)

        # Floor at min fee per transaction
        min_revenue = transaction_volume * self.min_fee
        afm_revenue = max(afm_revenue, min_revenue)

        return {
            "monthly_transactions": int(transaction_volume),
            "avg_transaction_usd": str(avg_transaction_size),
            "total_volume_usd": str(total_volume.quantize(Decimal("0.01"))),
            "afm_revenue_usd": str(afm_revenue.quantize(Decimal("0.01"))),
            "effective_rate_bps": self.commission_bps,
            "take_rate_pct": f"{self.commission_bps / 100:.2f}%",
        }


# Singleton
revenue_engine = AFMRevenueEngine()
