"""
AFM API Gateway — FastAPI with real payment endpoint
"""

import asyncio
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from decimal import Decimal
from typing import AsyncGenerator

from fastapi import FastAPI, Request, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import structlog
from pathlib import Path

from config.config import get_settings
from config.database import init_db, get_db, engine, AsyncSessionLocal
from config.exceptions import AFMException, AuthenticationError, ValidationError, NotFoundError, PaymentError
from config.logging_config import configure_logging
from config.security import (
    decode_token, create_access_token, create_refresh_token,
    hash_password, verify_password,
)
from event_bus.redis_producer import event_producer
from event_bus.event_schema import BaseEvent, EventType
from payment_hub.payment_service import payment_service
from payment_hub.models import Transaction, User

logger = configure_logging()
bearer_scheme = HTTPBearer()


async def get_current_user_id(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
) -> str:
    """
    CORRECTION (régression) : l'endpoint de paiement utilisait un user_id
    factice codé en dur ("user_demo_001") — ni un UUID valide, ni une ligne
    existante dans `users`, ce qui provoquait une erreur PostgreSQL (type UUID
    invalide + violation de contrainte de clé étrangère) sur CHAQUE appel.
    Le module JWT (`config/security.py`) existait déjà mais n'était jamais
    utilisé. Cette dépendance décode le token, vérifie que l'utilisateur
    existe réellement en base, et retourne son UUID.
    """
    payload = decode_token(credentials.credentials)
    if payload.get("type") != "access":
        raise AuthenticationError("Invalid token type")
    user_id = payload.get("sub")
    if not user_id:
        raise AuthenticationError("Token missing subject claim")

    from sqlalchemy import select
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        if not user:
            raise AuthenticationError("User not found")
    return user_id


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator:
    settings = get_settings()
    logger.info("Starting AFM API", environment=settings.environment)
    await init_db()
    yield
    logger.info("Shutting down AFM API")
    await payment_service.close()
    await event_producer.close()
    await engine.dispose()


app = FastAPI(
    title="Africa Frontier Markets API",
    description="B2B Fintech API for African payment corridors and US equity trading",
    version="prod-1.0.0",
    lifespan=lifespan,
    docs_url="/docs" if get_settings().is_development else None,
    redoc_url="/redoc" if get_settings().is_development else None,
)

app.add_middleware(GZipMiddleware, minimum_size=1000)

settings = get_settings()
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.get_allowed_origins(),
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
    allow_headers=["Authorization", "Content-Type", "X-Request-ID", "X-Idempotency-Key"],
    max_age=600,
)


@app.exception_handler(AFMException)
async def afm_exception_handler(request: Request, exc: AFMException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"error_code": exc.error_code, "detail": exc.detail},
    )


@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = datetime.now(timezone.utc)
    request_id = request.headers.get("X-Request-ID", "unknown")
    structlog.contextvars.clear_contextvars()
    structlog.contextvars.bind_contextvars(request_id=request_id, path=request.url.path)
    response = await call_next(request)
    duration = (datetime.now(timezone.utc) - start).total_seconds()
    logger.info(
        "Request completed",
        method=request.method,
        path=request.url.path,
        status=response.status_code,
        duration_ms=round(duration * 1000, 2),
    )
    return response


# Health probes
@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now(timezone.utc).isoformat()}


@app.get("/ready")
async def readiness_check():
    return {"status": "ready"}


PUBLIC_DIR = Path(__file__).resolve().parent.parent / "public"


@app.get("/")
async def root():
    """
    Sert le vitrine (public/index.html) à la racine du service.

    CORRECTION : cette route renvoyait auparavant un JSON avec
    "status": "operational" — une affirmation non vérifiée du même ordre
    que celles retirées du vitrine (voir public/index.html). Le service
    est en développement actif, pas "opérationnel" au sens production.
    """
    index_path = PUBLIC_DIR / "index.html"
    if index_path.exists():
        return FileResponse(index_path)
    return {"name": "Africa Frontier Markets", "status": "en développement"}


if PUBLIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(PUBLIC_DIR)), name="static")


from pydantic import BaseModel, Field


# ═══════════════════════════════════════════════════════════════════════════════
# AUTH — minimal register/login to obtain real JWT access tokens
# CORRECTION (régression) : aucun flux d'émission de token n'existait dans ce
# projet ; l'endpoint de paiement utilisait donc un user_id fabriqué. Ce n'est
# pas une fonctionnalité complète de gestion de compte (pas de reset password,
# pas de vérification email...), juste le minimum pour authentifier un
# utilisateur réel et obtenir un token exploitable par /api/v1/payments.
# ═══════════════════════════════════════════════════════════════════════════════

class RegisterRequest(BaseModel):
    email: str
    password: str = Field(..., min_length=8)
    full_name: str | None = None
    phone: str | None = None
    country: str | None = Field(None, min_length=2, max_length=2)


class LoginRequest(BaseModel):
    email: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user_id: str


@app.post("/api/v1/auth/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(payload: RegisterRequest):
    from sqlalchemy import select
    async with AsyncSessionLocal() as session:
        existing = await session.execute(select(User).where(User.email == payload.email))
        if existing.scalar_one_or_none():
            raise HTTPException(status_code=409, detail="Email already registered")

        user = User(
            email=payload.email,
            hashed_password=hash_password(payload.password),
            full_name=payload.full_name,
            phone=payload.phone,
            country=payload.country,
        )
        session.add(user)
        await session.commit()
        await session.refresh(user)

        access = create_access_token({"sub": str(user.id)})
        refresh = create_refresh_token({"sub": str(user.id)})
        return TokenResponse(access_token=access, refresh_token=refresh, user_id=str(user.id))


@app.post("/api/v1/auth/login", response_model=TokenResponse)
async def login(payload: LoginRequest):
    from sqlalchemy import select
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(User).where(User.email == payload.email))
        user = result.scalar_one_or_none()
        if not user or not user.hashed_password or not verify_password(payload.password, user.hashed_password):
            raise AuthenticationError("Invalid email or password")

        access = create_access_token({"sub": str(user.id)})
        refresh = create_refresh_token({"sub": str(user.id)})
        return TokenResponse(access_token=access, refresh_token=refresh, user_id=str(user.id))


# ═══════════════════════════════════════════════════════════════════════════════
# REAL PAYMENT ENDPOINT — POST /api/v1/payments
# ═══════════════════════════════════════════════════════════════════════════════


class PaymentRequest(BaseModel):
    amount: Decimal = Field(..., gt=0, description="Amount in local currency")
    currency: str = Field(..., min_length=3, max_length=3, description="XOF, XAF, NGN, KES, GHS, ZAR, USD, EUR, GBP")
    method: str = Field(default="mobile_money", description="mobile_money, card, bank_transfer, ussd")
    phone_number: str | None = Field(None, description="Required for mobile_money")
    region: str = Field(default="west_africa", description="west_africa, east_africa, south_africa, central_africa, international")
    metadata: dict = Field(default_factory=dict)


class PaymentResponse(BaseModel):
    transaction_id: str
    status: str
    amount: str
    currency: str
    fee_amount: str
    net_amount: str
    psp: str
    psp_transaction_id: str | None
    created_at: str


@app.post("/api/v1/payments", response_model=PaymentResponse, status_code=status.HTTP_201_CREATED)
async def create_payment(
    request: Request,
    payment: PaymentRequest,
    user_id: str = Depends(get_current_user_id),
):
    """
    Create a new payment — initiates REAL PSP processing.

    Flow:
    1. Validate request
    2. Route to appropriate PSP (Kora, Fincra, Flutterwave, MTN MoMo, Orange Money)
    3. Process payment via PSP API
    4. Store transaction in DB
    5. Return result

    Auth: Bearer <access_token> (voir /api/v1/auth/register ou /api/v1/auth/login).
    Idempotence : en-tête optionnel X-Idempotency-Key pour dédupliquer un retry
    réseau du même appel sans bloquer de nouveaux paiements légitimes.
    """
    client_idempotency_key = request.headers.get("X-Idempotency-Key")

    logger.info(
        "Payment request received",
        user_id=user_id,
        amount=str(payment.amount),
        currency=payment.currency,
        method=payment.method,
    )

    try:
        transaction = await payment_service.process_payment(
            user_id=user_id,
            amount=payment.amount,
            currency=payment.currency,
            method=payment.method,
            region=payment.region,
            phone_number=payment.phone_number,
            metadata=payment.metadata,
            idempotency_key=client_idempotency_key,
        )

        # Emit event for async processing (settlement, notifications)
        event = BaseEvent(
            event_type=EventType.PAYMENT_COMPLETED if transaction.status.value == "completed" else EventType.PAYMENT_FAILED,
            payload={
                "transaction_id": str(transaction.id),
                "user_id": str(transaction.user_id),
                "amount": str(transaction.amount),
                "currency": transaction.currency,
                "status": transaction.status.value,
                "psp": transaction.psp.value,
            },
        )
        await event_producer.publish(event)

        return PaymentResponse(
            transaction_id=str(transaction.id),
            status=transaction.status.value,
            amount=str(transaction.amount),
            currency=transaction.currency,
            fee_amount=str(transaction.fee_amount),
            net_amount=str(transaction.net_amount),
            psp=transaction.psp.value,
            psp_transaction_id=transaction.psp_transaction_id,
            created_at=transaction.created_at.isoformat(),
        )

    except AFMException:
        # CORRECTION : ce bloc catch-all convertissait TOUTES les erreurs métier
        # (ConflictError 409, CurrencyNotSupportedError 400, ValidationError 422...)
        # en 500 générique, masquant le vrai code HTTP et vidant de son sens le
        # gestionnaire afm_exception_handler défini plus haut dans ce fichier.
        # On laisse les AFMException remonter telles quelles vers ce handler.
        raise
    except Exception as e:
        logger.error("Payment processing failed", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/v1/payments/{transaction_id}")
async def get_payment(transaction_id: str, user_id: str = Depends(get_current_user_id)):
    """Get payment by ID.

    CORRECTION (régression) : cet endpoint n'était pas authentifié du tout —
    n'importe qui pouvait consulter la transaction de n'importe quel autre
    utilisateur en devinant/énumérant un UUID (IDOR). Il exige maintenant un
    token valide et vérifie que la transaction appartient à l'appelant.
    """
    try:
        transaction = await payment_service.get_transaction(transaction_id)
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))

    if str(transaction.user_id) != str(user_id):
        # 404 plutôt que 403 pour ne pas confirmer l'existence de la ressource à un tiers.
        raise HTTPException(status_code=404, detail="Transaction not found")

    return {
        "transaction_id": str(transaction.id),
        "status": transaction.status.value,
        "amount": str(transaction.amount),
        "currency": transaction.currency,
        "psp": transaction.psp.value,
        "psp_transaction_id": transaction.psp_transaction_id,
        "psp_response": transaction.psp_response,
        "created_at": transaction.created_at.isoformat(),
        "updated_at": transaction.updated_at.isoformat(),
    }


# Webhook endpoints with HMAC verification + déduplication anti-rejeu
@app.post("/webhooks/kora")
async def kora_webhook(request: Request):
    payload = await request.body()
    signature = request.headers.get("X-Kora-Signature", "")

    try:
        result = await payment_service.process_webhook("kora", payload, signature)
    except PaymentError:
        raise HTTPException(status_code=401, detail="Invalid signature")

    logger.info("Kora webhook processed", **result)
    return result


@app.post("/webhooks/fincra")
async def fincra_webhook(request: Request):
    payload = await request.body()
    signature = request.headers.get("X-Fincra-Signature", "")

    try:
        result = await payment_service.process_webhook("fincra", payload, signature)
    except PaymentError:
        raise HTTPException(status_code=401, detail="Invalid signature")

    logger.info("Fincra webhook processed", **result)
    return result


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "api_gateway.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.is_development,
        access_log=False,
    )
