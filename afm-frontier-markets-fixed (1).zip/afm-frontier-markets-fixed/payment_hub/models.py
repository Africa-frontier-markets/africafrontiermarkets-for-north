"""
AFM Payment Hub Models — SQLAlchemy 2.0 with DB persistence
"""

from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum
from uuid import uuid4

from sqlalchemy import Column, String, DateTime, Numeric, Enum as SQLEnum, ForeignKey, JSON, Index, Text
from sqlalchemy.dialects.postgresql import UUID

from config.database import Base


class PaymentStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    REFUNDED = "refunded"
    HELD = "held"
    # AJOUT (réponse à l'audit, section 4.3 "Idempotence et double paiement") :
    # un timeout réseau vers un PSP ne dit RIEN sur le résultat réel côté PSP
    # — le paiement peut avoir été traité malgré l'absence de réponse reçue.
    # Marquer ça FAILED (comme le faisait le code précédent) est dangereux :
    # ça peut laisser croire qu'un nouvel essai est sans risque, alors que le
    # premier a peut-être réussi (double paiement). AMBIGUOUS force une
    # vérification de statut auprès du PSP avant toute résolution — voir
    # payment_service._call_psp_api et _check_psp_status.
    AMBIGUOUS = "ambiguous"


class PSPType(str, Enum):
    KORA = "kora"
    FINCRA = "fincra"
    FLUTTERWAVE = "flutterwave"
    STRIPE = "stripe"
    MTN_MOMO = "mtn_momo"
    ORANGE_MONEY = "orange_money"


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    idempotency_key = Column(String(64), unique=True, nullable=False, index=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, index=True)
    psp = Column(SQLEnum(PSPType), nullable=False)
    psp_transaction_id = Column(String(100))
    psp_response = Column(JSON, default=dict)  # Raw PSP response stored
    amount = Column(Numeric(19, 8), nullable=False)
    currency = Column(String(3), nullable=False)
    fee_amount = Column(Numeric(19, 8), default=Decimal("0"))
    fee_currency = Column(String(3), default="USD")
    net_amount = Column(Numeric(19, 8), default=Decimal("0"))
    status = Column(SQLEnum(PaymentStatus), default=PaymentStatus.PENDING)
    # CORRECTION (régression) : "metadata" est un attribut réservé par la Base
    # déclarative de SQLAlchemy (déjà signalé et corrigé sur la V38 — réintroduit
    # ici dans la réécriture). InvalidRequestError garantie au chargement du
    # modèle -> AUCUN module de payment_hub ne pouvait s'importer, y compris
    # api_gateway.main. Colonne DB inchangée ("metadata"), attribut Python renommé.
    extra_data = Column("metadata", JSON, default=dict)
    error_message = Column(Text)
    webhook_received_at = Column(DateTime(timezone=True))
    settled_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_transactions_user_status", "user_id", "status"),
        Index("ix_transactions_created_at", "created_at"),
        Index("ix_transactions_psp_txn", "psp_transaction_id"),
    )


class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255))
    full_name = Column(String(255))
    phone = Column(String(50))
    country = Column(String(2))
    is_active = Column(String(1), default="1")
    kyc_status = Column(String(20), default="pending")
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class WebhookEvent(Base):
    """
    Trace de chaque webhook PSP reçu, avec une clé de déduplication.

    AJOUT (réponse à l'audit — test pratique n°5 exigé : "Webhook replay :
    rejeu d'un ancien événement -> résultat attendu : rejet ou
    déduplication"). Avant cette correction, un webhook rejouait sa
    logique intégralement à chaque appel (aucune trace, aucune détection).

    dedup_key = l'identifiant d'événement fourni par le PSP s'il existe
    (le plus fiable), sinon sha256(payload brut). La contrainte unique sur
    (psp, dedup_key) fait que la 2e insertion du même événement lève une
    IntegrityError — capturée par payment_service pour répondre
    "déjà traité" sans ré-exécuter d'effet de bord.
    """
    __tablename__ = "webhook_events"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    psp = Column(String(32), nullable=False)
    dedup_key = Column(String(128), nullable=False)
    event_type = Column(String(64), nullable=True)
    transaction_id = Column(UUID(as_uuid=True), ForeignKey("transactions.id"), nullable=True, index=True)
    payload = Column(JSON, nullable=False)
    received_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    processed_at = Column(DateTime(timezone=True), nullable=True)

    __table_args__ = (
        Index("ix_webhook_events_dedup", "psp", "dedup_key", unique=True),
    )
