"""
AFM Payment Service — REAL DB persistence + REAL HTTP calls to PSPs
"""

import hashlib
import json
from decimal import Decimal, ROUND_HALF_UP
from datetime import datetime, timezone
from typing import Optional, Dict, Any
from uuid import uuid4

import httpx
import redis.asyncio as aioredis
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from config.config import get_settings
from config.database import AsyncSessionLocal
from config.exceptions import (
    PaymentError, ConflictError, CurrencyNotSupportedError,
    ValidationError, PSPAPIError, NotFoundError, LedgerError,
)
from config.security import hash_idempotency_key
from config.logging_config import configure_logging
from payment_hub.models import Transaction, PaymentStatus, PSPType, WebhookEvent
from payment_hub.psp_router import psp_router
from payment_hub.ledger_engine import ledger_engine
from revenue_engine.revenue_engine import revenue_engine

logger = configure_logging()


class PaymentService:
    """
    AFM Payment Service — Production Implementation

    Features:
    - REAL DB persistence (session.add() + commit())
    - REAL HTTP calls to PSP APIs (Kora, Fincra, Flutterwave)
    - Idempotency with SHA256 keys
    - Commission calculation (AFM B2B model: 25 bps)
    """

    SUPPORTED_CURRENCIES = {
        "XOF", "XAF", "NGN", "KES", "GHS", "ZAR",
        "USD", "EUR", "GBP",
    }

    def __init__(self):
        self._http_client: Optional[httpx.AsyncClient] = None
        self._redis: Optional[aioredis.Redis] = None

    async def _get_http_client(self) -> httpx.AsyncClient:
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(timeout=30.0)
        return self._http_client

    async def _get_redis(self) -> aioredis.Redis:
        # CORRECTION (régression) : l'ancien verrou anticipé était un set()
        # Python en mémoire (self._pending_locks) — perdu au redémarrage et non
        # partagé entre réplicas, donc sans effet réel à l'échelle. Remplacé
        # par un verrou Redis (SET NX + TTL court) qui fonctionne quel que soit
        # le nombre d'instances du service.
        if self._redis is None:
            settings = get_settings()
            self._redis = aioredis.from_url(settings.redis_url, decode_responses=True)
        return self._redis

    def _generate_idempotency_key(
        self, user_id: str, amount: str, currency: str, client_key: Optional[str] = None
    ) -> str:
        """
        CORRECTION (régression) : la clé précédente était dérivée de
        user_id + montant + devise + DATE DU JOUR (granularité jour, pas
        requête). Deux paiements légitimes et distincts du même montant, dans
        la même devise, le même jour, étaient rejetés à tort comme des
        doublons ("ConflictError: Duplicate payment detected").

        Comportement correct :
        - si le client fournit une clé d'idempotence (header X-Idempotency-Key,
          déjà annoncé dans les CORS mais jamais lue auparavant), on l'utilise :
          c'est la seule façon fiable de dédupliquer un retry réseau du MÊME
          appel sans bloquer de nouveaux paiements légitimes.
        - sinon, on génère une clé aléatoire par requête (uuid4) : chaque appel
          sans clé explicite est traité comme un nouveau paiement, ce qui est
          le comportement attendu par défaut.
        """
        if client_key:
            key = f"{user_id}:{client_key}"
            return hashlib.sha256(key.encode()).hexdigest()
        return hashlib.sha256(f"{user_id}:{amount}:{currency}:{uuid4()}".encode()).hexdigest()

    def _calculate_afm_fee(self, amount: Decimal, currency: str, psp: str = "kora") -> tuple[Decimal, Decimal]:
        """
        CORRECTION (régression) : cette méthode dupliquait la logique de
        revenue_engine.calculate_fee() avec un risque de divergence entre les
        deux (même règle métier maintenue à deux endroits). Elle délègue
        maintenant au moteur central pour qu'il n'existe qu'une seule source
        de vérité pour le calcul de commission AFM.
        """
        breakdown = revenue_engine.calculate_fee(amount, currency=currency, psp=psp)
        return breakdown.afm_fee, breakdown.net_amount

    async def process_payment(
        self,
        user_id: str,
        amount: Decimal,
        currency: str,
        method: str = "mobile_money",
        region: str = "west_africa",
        phone_number: Optional[str] = None,
        metadata: Optional[Dict] = None,
        idempotency_key: Optional[str] = None,
    ) -> Transaction:
        """
        Process a payment end-to-end:
        1. Validate inputs
        2. Generate idempotency key (client-supplied if provided)
        3. Select PSP
        4. Create DB record (PENDING)
        5. Call PSP API
        6. Update DB with result
        7. Return transaction
        """

        # 1. Validate
        currency = currency.upper()
        if currency not in self.SUPPORTED_CURRENCIES:
            raise CurrencyNotSupportedError(f"Currency {currency} not supported")

        if amount <= 0:
            raise ValidationError("Amount must be greater than 0")

        if phone_number is None and method == "mobile_money":
            raise ValidationError("phone_number required for mobile_money")

        # 2. Idempotency
        computed_key = self._generate_idempotency_key(
            str(user_id), str(amount), currency, client_key=idempotency_key
        )

        # Verrou Redis à courte durée : protège la fenêtre entre le SELECT et
        # l'INSERT ci-dessous, y compris entre plusieurs réplicas du service
        # (contrairement à l'ancien set() Python en mémoire, local à un process).
        r = await self._get_redis()
        lock_key = f"payment:lock:{computed_key}"
        acquired = await r.set(lock_key, "1", nx=True, ex=30)
        if not acquired:
            raise ConflictError("Duplicate payment detected (already in progress)")

        try:
            # 3. Select PSP
            psp = psp_router.select_psp(currency, method=method, region=region, amount=str(amount))

            # 4. Calculate fee
            fee_amount, net_amount = self._calculate_afm_fee(amount, currency, psp=psp.value)

            # 5. Create DB record — REAL PERSISTENCE
            async with AsyncSessionLocal() as session:
                from sqlalchemy import select
                result = await session.execute(
                    select(Transaction).where(Transaction.idempotency_key == computed_key)
                )
                existing = result.scalar_one_or_none()
                if existing:
                    raise ConflictError(f"Transaction with idempotency key already exists: {existing.id}")

                transaction = Transaction(
                    idempotency_key=computed_key,
                    user_id=user_id,
                    psp=psp,
                    amount=amount,
                    currency=currency,
                    fee_amount=fee_amount,
                    # CORRECTION : "USD" en dur ici alors que `amount` est dans
                    # la devise locale de la transaction rendait le ledger
                    # impossible à équilibrer sans un compte de conversion FX
                    # (voir ledger_engine.post_payment_completed). Les frais
                    # sont désormais dans la même devise que la transaction.
                    fee_currency=currency,
                    net_amount=net_amount,
                    status=PaymentStatus.PENDING,
                    extra_data=metadata or {},
                )
                session.add(transaction)  # ← REAL DB WRITE
                try:
                    await session.commit()     # ← REAL COMMIT
                except IntegrityError:
                    # CORRECTION (régression) : deux requêtes concurrentes peuvent
                    # passer le SELECT ci-dessus avant que l'une des deux ne commite
                    # (le verrou Redis réduit la fenêtre mais ne l'élimine pas à 100%
                    # en cas d'expiration/054 pathologique). La contrainte unique en
                    # base est le filet de sécurité final : on récupère la
                    # transaction existante plutôt que de laisser fuiter une 500.
                    await session.rollback()
                    result = await session.execute(
                        select(Transaction).where(Transaction.idempotency_key == computed_key)
                    )
                    existing = result.scalar_one_or_none()
                    if existing:
                        raise ConflictError(f"Transaction with idempotency key already exists: {existing.id}")
                    raise
                await session.refresh(transaction)

                logger.info(
                    "Transaction created in DB",
                    transaction_id=str(transaction.id),
                    idempotency_key=computed_key,
                    psp=psp.value,
                    amount=str(amount),
                    currency=currency,
                )

                # 6. Call PSP API — REAL HTTP CALL
                psp_response = await self._call_psp_api(
                    psp=psp,
                    transaction=transaction,
                    phone_number=phone_number,
                    method=method,
                )

                # 7. Update DB with PSP result
                #
                # CORRECTION (audit, section 4.3 "Idempotence et double
                # paiement") : l'ancien code ne connaissait que deux issues
                # (success True/False) et traitait toute exception HTTP —
                # y compris un TIMEOUT — comme un échec définitif (FAILED).
                # C'est dangereux : un timeout signifie "je ne sais pas ce qui
                # s'est passé côté PSP", pas "le PSP a refusé le paiement".
                # Un appelant qui voit FAILED peut légitimement réessayer, ce
                # qui peut produire un double paiement si le premier essai a
                # en réalité été traité par le PSP.
                #
                # Nouveau comportement :
                #   - réponse PSP définitive (succès ou échec confirmé) -> COMPLETED/FAILED
                #   - timeout/erreur réseau (ambiguë) -> on interroge le statut
                #     PSP AVANT de conclure quoi que ce soit ; si le statut
                #     lui-même ne résout pas l'ambiguïté, la transaction reste
                #     AMBIGUOUS et n'est JAMAIS auto-résolue en COMPLETED ou
                #     FAILED sans confirmation positive.
                transaction.psp_transaction_id = psp_response.get("psp_transaction_id")
                transaction.psp_response = psp_response

                if psp_response.get("ambiguous"):
                    logger.error(
                        "PSP response ambiguous after timeout/network error — querying status before any conclusion",
                        transaction_id=str(transaction.id),
                        psp=psp.value,
                    )
                    status_result = await self._check_psp_status(psp, transaction)

                    if status_result.get("resolved"):
                        if status_result.get("success"):
                            transaction.status = PaymentStatus.COMPLETED
                            transaction.settled_at = datetime.now(timezone.utc)
                        else:
                            transaction.status = PaymentStatus.FAILED
                            transaction.error_message = status_result.get("error", "PSP confirmed failure on status check")
                    else:
                        # Toujours pas résolu : on NE devine PAS. La transaction
                        # reste explicitement AMBIGUOUS, le verrou Redis est
                        # prolongé (pas relâché immédiatement) pour empêcher
                        # qu'un nouvel essai parte trop vite sur le même
                        # paiement logique, et un événement est publié pour
                        # qu'une réconciliation manuelle prenne le relais.
                        transaction.status = PaymentStatus.AMBIGUOUS
                        transaction.error_message = "PSP status unresolved after timeout — requires manual reconciliation"
                        await r.expire(lock_key, 3600)  # garde le verrou 1h le temps d'investiguer

                elif psp_response.get("success"):
                    transaction.status = PaymentStatus.COMPLETED
                    transaction.settled_at = datetime.now(timezone.utc)
                else:
                    transaction.status = PaymentStatus.FAILED
                    transaction.error_message = psp_response.get("error", "PSP processing failed")

                # 8. Ledger — uniquement pour une complétion réellement confirmée.
                # CORRECTION (audit, section 2.2/4.2) : aucune écriture
                # comptable n'existait auparavant ; le "ledger" se résumait au
                # champ Transaction.status. Chaque paiement COMPLETED génère
                # maintenant un journal équilibré et immuable (voir
                # ledger_engine.post_payment_completed).
                if transaction.status == PaymentStatus.COMPLETED:
                    try:
                        journal_id = await ledger_engine.post_payment_completed(
                            session,
                            user_id=transaction.user_id,
                            amount=transaction.amount,
                            fee_amount=transaction.fee_amount,
                            net_amount=transaction.net_amount,
                            currency=transaction.currency,
                            transaction_id=transaction.id,
                        )
                        transaction.extra_data = {**(transaction.extra_data or {}), "ledger_journal_id": str(journal_id)}
                    except LedgerError as e:
                        # Un ledger déséquilibré n'est jamais acceptable, même
                        # si le PSP a confirmé le paiement : on marque la
                        # transaction en litige plutôt que de committer une
                        # écriture invalide.
                        logger.error("Ledger posting failed for completed payment", transaction_id=str(transaction.id), error=str(e))
                        transaction.status = PaymentStatus.AMBIGUOUS
                        transaction.error_message = f"Payment confirmed by PSP but ledger posting failed: {e}"

                await session.commit()  # ← REAL UPDATE

                logger.info(
                    "Transaction finalized",
                    transaction_id=str(transaction.id),
                    status=transaction.status.value,
                    psp_txn_id=transaction.psp_transaction_id,
                )

                return transaction

        finally:
            # Le verrou n'est relâché ici que s'il n'a pas déjà été prolongé
            # ci-dessus pour une transaction AMBIGUOUS (auquel cas on veut
            # qu'il expire naturellement après 1h, pas qu'il soit supprimé
            # immédiatement).
            current_ttl = await r.ttl(lock_key)
            if current_ttl is not None and current_ttl <= 30:
                await r.delete(lock_key)

    async def _call_psp_api(
        self,
        psp: PSPType,
        transaction: Transaction,
        phone_number: Optional[str],
        method: str,
    ) -> Dict[str, Any]:
        """
        REAL HTTP call to PSP API.

        CORRECTION (audit, section 4.3) : l'ancien `except httpx.HTTPError`
        attrapait indifféremment les timeouts/erreurs réseau ET les réponses
        HTTP d'erreur confirmées (4xx/5xx), et traitait les deux comme un
        échec définitif. Or `httpx.TimeoutException` et
        `httpx.NetworkError`/`httpx.ConnectError` signifient "je ne sais pas
        ce qui s'est passé côté PSP" — le paiement a peut-être été traité
        malgré l'absence de réponse. Ces cas sont maintenant marqués
        `ambiguous: True` et déclenchent une vérification de statut avant
        toute conclusion (voir process_payment et _check_psp_status),
        au lieu d'être auto-résolus en échec.
        """
        settings = get_settings()
        client = await self._get_http_client()

        try:
            if psp in (PSPType.KORA, PSPType.MTN_MOMO, PSPType.ORANGE_MONEY):
                return await self._call_kora(client, transaction, phone_number, settings)
            elif psp == PSPType.FINCRA:
                return await self._call_fincra(client, transaction, settings)
            elif psp == PSPType.FLUTTERWAVE:
                return await self._call_flutterwave(client, transaction, phone_number, settings)
            elif psp == PSPType.STRIPE:
                return await self._call_stripe(client, transaction, settings)
            else:
                raise PSPAPIError(f"Unsupported PSP: {psp}")

        except (httpx.TimeoutException, httpx.NetworkError, httpx.ConnectError) as e:
            # Issue réellement inconnue : ne PAS marquer comme échec.
            logger.error(
                "PSP call timed out or network error — outcome unknown, marking ambiguous",
                psp=psp.value, error=str(e),
            )
            return {"success": False, "ambiguous": True, "error": f"Network/timeout error: {e}"}
        except httpx.HTTPStatusError as e:
            # Le PSP a répondu, avec un code d'erreur explicite : c'est un
            # échec confirmé, pas une ambiguïté.
            logger.error("PSP returned an explicit error status", psp=psp.value, error=str(e))
            return {"success": False, "ambiguous": False, "error": f"PSP HTTP error: {e}"}
        except httpx.HTTPError as e:
            # Toute autre erreur httpx non classifiée ci-dessus : par
            # prudence, traiter comme ambiguë plutôt que comme un échec
            # certain — mieux vaut une vérification de statut superflue
            # qu'un double paiement silencieux.
            logger.error("Unclassified PSP HTTP error — treating as ambiguous by default", psp=psp.value, error=str(e))
            return {"success": False, "ambiguous": True, "error": f"HTTP error: {e}"}
        except Exception as e:
            logger.error("PSP API error", psp=psp.value, error=str(e))
            return {"success": False, "ambiguous": False, "error": str(e)}

    async def _check_psp_status(self, psp: PSPType, transaction: Transaction) -> Dict[str, Any]:
        """
        Interroge le PSP sur le statut réel d'une transaction ambiguë, en
        utilisant la référence externe déterministe déjà envoyée
        (transaction.idempotency_key comme `reference`/`tx_ref` — voir
        _call_kora/_call_fincra/_call_flutterwave). C'est cette référence
        déterministe, et non un nouvel identifiant généré à la volée, qui
        permet de retrouver la BONNE transaction côté PSP.

        ATTENTION (non simulable sans intégration réelle) : comme pour
        SANDBOX_MODE dans la V38, ceci nécessite le vrai endpoint de
        consultation de statut de chaque PSP (ex: GET
        /merchant/api/v1/charges/{reference} pour Kora). Sans identifiants
        réels, on ne peut pas deviner l'issue réelle.

        Cette méthode NE LÈVE JAMAIS d'exception (correction : une version
        antérieure levait NotImplementedError hors développement, ce qui
        faisait planter process_payment AVANT le commit — la transaction
        restait alors bloquée en PENDING en base, sans aucun statut clair
        ni trace exploitable). Elle retourne systématiquement
        `resolved: False` tant qu'aucune intégration réelle n'existe,
        avec une sévérité de log qui reflète la gravité réelle : simple
        avertissement en développement (attendu), erreur critique en
        staging/production (lacune bloquante qui empêche de résoudre
        automatiquement une transaction ambiguë — condition identifiée
        par l'audit, section 4.3).
        """
        settings = get_settings()
        if settings.is_development:
            logger.warning(
                "PSP status check not implemented for real (dev mode) — "
                "cannot resolve ambiguous transaction automatically, "
                "leaving it AMBIGUOUS for manual/reconciliation review",
                psp=psp.value, transaction_id=str(transaction.id),
            )
        else:
            logger.critical(
                "PSP status check NOT IMPLEMENTED outside development — "
                "cannot auto-resolve an ambiguous transaction; this is a "
                "blocking integration gap that must be closed before "
                "production use (audit section 4.3)",
                psp=psp.value, transaction_id=str(transaction.id),
            )
        return {"resolved": False}

    async def _call_kora(
        self,
        client: httpx.AsyncClient,
        transaction: Transaction,
        phone_number: Optional[str],
        settings: Any,
    ) -> Dict[str, Any]:
        """Call Kora API for mobile money or card payments."""

        url = "https://api.korapay.com/merchant/api/v1/charges/mobile-money"

        payload = {
            "amount": float(transaction.amount),
            "currency": transaction.currency,
            "reference": transaction.idempotency_key,
            "customer": {
                "email": transaction.extra_data.get("email", "customer@afm.com"),
                "name": transaction.extra_data.get("name", "AFM Customer"),
            },
            "mobile_money": {
                "phone": phone_number,
                "provider": self._detect_provider(phone_number, transaction.currency),
            } if phone_number else None,
        }

        headers = {
            "Authorization": f"Bearer {settings.kora_secret_key}",
            "Content-Type": "application/json",
        }

        # In development/staging: simulate success
        if settings.is_development or not settings.kora_secret_key:
            logger.warning("Kora API call simulated (dev/no credentials)")
            return {
                "success": True,
                "psp_transaction_id": f"kora_sim_{hashlib.sha256(transaction.idempotency_key.encode()).hexdigest()[:16]}",
                "status": "success",
                "message": "Payment successful (simulated)",
            }

        response = await client.post(url, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

        return {
            "success": data.get("status") == "success",
            "psp_transaction_id": data.get("data", {}).get("reference"),
            "status": data.get("status"),
            "raw_response": data,
        }

    async def _call_fincra(
        self,
        client: httpx.AsyncClient,
        transaction: Transaction,
        settings: Any,
    ) -> Dict[str, Any]:
        """Call Fincra API."""

        url = "https://api.fincra.com/disbursements/payouts"

        payload = {
            "amount": float(transaction.amount),
            "currency": transaction.currency,
            "reference": transaction.idempotency_key,
            "business": settings.fincra_api_key,
            "description": f"AFM Payment {transaction.idempotency_key}",
        }

        headers = {
            "api-key": settings.fincra_secret_key,
            "Content-Type": "application/json",
        }

        if settings.is_development or not settings.fincra_secret_key:
            logger.warning("Fincra API call simulated (dev/no credentials)")
            return {
                "success": True,
                "psp_transaction_id": f"fincra_sim_{hashlib.sha256(transaction.idempotency_key.encode()).hexdigest()[:16]}",
                "status": "success",
            }

        response = await client.post(url, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

        return {
            "success": data.get("status") == "success",
            "psp_transaction_id": data.get("data", {}).get("reference"),
            "raw_response": data,
        }

    async def _call_flutterwave(
        self,
        client: httpx.AsyncClient,
        transaction: Transaction,
        phone_number: Optional[str],
        settings: Any,
    ) -> Dict[str, Any]:
        """Call Flutterwave API."""

        url = "https://api.flutterwave.com/v3/charges?type=mobile_money_"

        payload = {
            "amount": float(transaction.amount),
            "currency": transaction.currency,
            "tx_ref": transaction.idempotency_key,
            "phone_number": phone_number,
        }

        headers = {
            "Authorization": f"Bearer {settings.flutterwave_secret_key}",
            "Content-Type": "application/json",
        }

        if settings.is_development or not settings.flutterwave_secret_key:
            logger.warning("Flutterwave API call simulated (dev/no credentials)")
            return {
                "success": True,
                "psp_transaction_id": f"fw_sim_{hashlib.sha256(transaction.idempotency_key.encode()).hexdigest()[:16]}",
                "status": "success",
            }

        response = await client.post(url, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

        return {
            "success": data.get("status") == "success",
            "psp_transaction_id": data.get("data", {}).get("id"),
            "raw_response": data,
        }

    async def _call_stripe(
        self,
        client: httpx.AsyncClient,
        transaction: Transaction,
        settings: Any,
    ) -> Dict[str, Any]:
        """Call Stripe API."""

        url = "https://api.stripe.com/v1/payment_intents"

        payload = {
            "amount": int(transaction.amount * 100),  # cents
            "currency": transaction.currency.lower(),
            "metadata[afm_reference]": transaction.idempotency_key,
        }

        headers = {
            "Authorization": f"Bearer {settings.stripe_secret_key}",
        }

        if settings.is_development or not settings.stripe_secret_key:
            logger.warning("Stripe API call simulated (dev/no credentials)")
            return {
                "success": True,
                "psp_transaction_id": f"stripe_sim_{hashlib.sha256(transaction.idempotency_key.encode()).hexdigest()[:16]}",
                "status": "requires_confirmation",
            }

        response = await client.post(url, data=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

        return {
            "success": data.get("status") in ("succeeded", "requires_confirmation"),
            "psp_transaction_id": data.get("id"),
            "client_secret": data.get("client_secret"),
            "raw_response": data,
        }

    def _detect_provider(self, phone_number: str, currency: str) -> str:
        """Detect mobile money provider from phone number prefix."""
        # Simple heuristic — enhance with real mapping
        if currency == "XOF":
            if phone_number.startswith(("+223", "223")):  # Mali
                return "orange_money"
            elif phone_number.startswith(("+225", "225")):  # Côte d'Ivoire
                return "mtn"
            elif phone_number.startswith(("+221", "221")):  # Sénégal
                return "wave"
        elif currency == "XAF":
            if phone_number.startswith(("+237", "237")):  # Cameroun
                return "mtn"
        elif currency == "NGN":
            return "mtn"
        elif currency == "KES":
            return "mpesa"
        elif currency == "GHS":
            return "mtn"
        return "mtn"  # default

    async def get_transaction(self, transaction_id: str) -> Transaction:
        """Get transaction by ID."""
        async with AsyncSessionLocal() as session:
            from sqlalchemy import select
            result = await session.execute(
                select(Transaction).where(Transaction.id == transaction_id)
            )
            transaction = result.scalar_one_or_none()
            if not transaction:
                raise NotFoundError(f"Transaction {transaction_id} not found")
            return transaction

    async def verify_webhook(self, psp: str, payload: bytes, signature: str) -> bool:
        """Verify webhook HMAC signature."""
        from config.security import verify_webhook_signature
        settings = get_settings()
        secrets_map = {
            "kora": settings.kora_webhook_secret,
            "fincra": settings.fincra_webhook_secret,
        }
        secret = secrets_map.get(psp)
        if not secret:
            return False
        return verify_webhook_signature(payload, signature, secret)

    async def process_webhook(self, psp: str, payload: bytes, signature: str) -> Dict[str, Any]:
        """
        Traite un webhook PSP de bout en bout : vérification de signature,
        déduplication anti-rejeu, puis résolution de la transaction visée.

        AJOUT (audit, test pratique n°5 : "Webhook replay : rejeu d'un
        ancien événement -> rejet ou déduplication"). Avant cette
        correction, un webhook était vérifié (signature) puis... rien :
        aucune trace, aucun effet, et un rejeu produisait exactement le
        même comportement à chaque fois (donc ni rejeté ni dédupliqué,
        juste ignoré silencieusement — ce qui n'est pas mieux).

        Comportement :
        1. Signature invalide -> rejet (levée par l'appelant, inchangé)
        2. dedup_key = event id fourni par le PSP si présent, sinon
           sha256(payload brut)
        3. Insertion de WebhookEvent avec contrainte UNIQUE (psp, dedup_key) :
           si déjà vu, IntegrityError -> on répond "duplicate" sans
           ré-exécuter le moindre effet de bord.
        4. Si nouveau : on retrouve la transaction par référence
           déterministe (idempotency_key envoyé comme reference/tx_ref au
           PSP) et on résout son statut si elle était PENDING/AMBIGUOUS.
        """
        if not await self.verify_webhook(psp, payload, signature):
            raise PaymentError("Invalid webhook signature")

        data = json.loads(payload)
        event_id = data.get("event_id") or data.get("id") or data.get("data", {}).get("id")
        dedup_key = str(event_id) if event_id else hashlib.sha256(payload).hexdigest()
        event_type = data.get("event") or data.get("type")
        reference = (
            data.get("data", {}).get("reference")
            or data.get("data", {}).get("tx_ref")
            or data.get("reference")
        )

        async with AsyncSessionLocal() as session:
            webhook_event = WebhookEvent(
                psp=psp, dedup_key=dedup_key, event_type=event_type, payload=data,
            )
            session.add(webhook_event)
            try:
                await session.commit()
            except IntegrityError:
                await session.rollback()
                logger.warning("Duplicate webhook received — ignored", psp=psp, dedup_key=dedup_key)
                return {"status": "duplicate_ignored", "event": event_type}

            if not reference:
                logger.warning("Webhook received without a resolvable transaction reference", psp=psp, event=event_type)
                return {"status": "received_no_reference", "event": event_type}

            result = await session.execute(
                select(Transaction).where(Transaction.idempotency_key == reference)
            )
            transaction = result.scalar_one_or_none()
            if not transaction:
                logger.warning("Webhook reference does not match any known transaction", psp=psp, reference=reference)
                return {"status": "received_unknown_transaction", "event": event_type}

            webhook_event.transaction_id = transaction.id

            # On ne résout que les transactions dans un état non final —
            # jamais réécrire un COMPLETED/FAILED déjà établi à partir d'un
            # webhook tardif ou rejoué (l'immuabilité s'applique aussi ici).
            if transaction.status in (PaymentStatus.PENDING, PaymentStatus.PROCESSING, PaymentStatus.AMBIGUOUS):
                webhook_success = data.get("data", {}).get("status") in ("success", "successful", "completed")
                was_ambiguous = transaction.status == PaymentStatus.AMBIGUOUS

                if webhook_success:
                    transaction.status = PaymentStatus.COMPLETED
                    transaction.settled_at = datetime.now(timezone.utc)
                    if transaction.status == PaymentStatus.COMPLETED and not (transaction.extra_data or {}).get("ledger_journal_id"):
                        try:
                            journal_id = await ledger_engine.post_payment_completed(
                                session,
                                user_id=transaction.user_id,
                                amount=transaction.amount,
                                fee_amount=transaction.fee_amount,
                                net_amount=transaction.net_amount,
                                currency=transaction.currency,
                                transaction_id=transaction.id,
                            )
                            transaction.extra_data = {**(transaction.extra_data or {}), "ledger_journal_id": str(journal_id)}
                        except LedgerError as e:
                            logger.error("Ledger posting failed while resolving webhook", transaction_id=str(transaction.id), error=str(e))
                else:
                    transaction.status = PaymentStatus.FAILED
                    transaction.error_message = "Resolved as failed via PSP webhook"

                transaction.webhook_received_at = datetime.now(timezone.utc)
                logger.info(
                    "Transaction resolved via webhook",
                    transaction_id=str(transaction.id),
                    was_ambiguous=was_ambiguous,
                    new_status=transaction.status.value,
                )

            webhook_event.processed_at = datetime.now(timezone.utc)
            await session.commit()

        return {"status": "processed", "event": event_type}

    async def close(self):
        if self._http_client:
            await self._http_client.aclose()
        if self._redis:
            await self._redis.close()


# Singleton
payment_service = PaymentService()
