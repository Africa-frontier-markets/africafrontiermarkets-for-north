"""
AFM PSP Router — Currency & Region Based Routing
Includes MTN MoMo and Orange Money for African corridors
"""

from decimal import Decimal

from config.config import get_settings
from config.exceptions import PaymentError, CurrencyNotSupportedError
from payment_hub.models import PSPType

settings = get_settings()


class PSPRouter:
    """
    Routes payments to the appropriate PSP based on:
    - Currency (XOF, XAF, NGN, KES, GHS, ZAR, USD, EUR, GBP)
    - Payment method (mobile_money, card, bank_transfer)
    - Region (west_africa, east_africa, south_africa, international)
    """

    # Currency → supported PSPs (including mobile money operators)
    CURRENCY_PSP_MAP = {
        # West African CFA — Mobile Money primary
        "XOF": [PSPType.MTN_MOMO, PSPType.ORANGE_MONEY, PSPType.KORA, PSPType.FINCRA, PSPType.FLUTTERWAVE],
        "XAF": [PSPType.MTN_MOMO, PSPType.ORANGE_MONEY, PSPType.KORA, PSPType.FINCRA, PSPType.FLUTTERWAVE],
        # Nigerian Naira
        "NGN": [PSPType.KORA, PSPType.FINCRA, PSPType.FLUTTERWAVE],
        # Kenyan Shilling
        "KES": [PSPType.MTN_MOMO, PSPType.KORA, PSPType.FINCRA],
        # Ghana Cedi
        "GHS": [PSPType.MTN_MOMO, PSPType.KORA, PSPType.FINCRA, PSPType.FLUTTERWAVE],
        # South African Rand
        "ZAR": [PSPType.FINCRA, PSPType.STRIPE],
        # Major internationals
        "USD": [PSPType.FINCRA, PSPType.STRIPE],
        "EUR": [PSPType.FINCRA, PSPType.STRIPE],
        "GBP": [PSPType.FINCRA, PSPType.STRIPE],
    }

    # Method preferences per PSP
    METHOD_PSP_MAP = {
        "mobile_money": [PSPType.MTN_MOMO, PSPType.ORANGE_MONEY, PSPType.KORA, PSPType.FLUTTERWAVE],
        "card": [PSPType.FLUTTERWAVE, PSPType.STRIPE, PSPType.FINCRA],
        "bank_transfer": [PSPType.KORA, PSPType.FINCRA, PSPType.STRIPE],
        "ussd": [PSPType.KORA, PSPType.FLUTTERWAVE],
    }

    # Region preferences (first = preferred)
    REGION_PSP_PRIORITY = {
        "west_africa": [PSPType.MTN_MOMO, PSPType.ORANGE_MONEY, PSPType.KORA, PSPType.FLUTTERWAVE, PSPType.FINCRA],
        "east_africa": [PSPType.MTN_MOMO, PSPType.KORA, PSPType.FINCRA],
        "south_africa": [PSPType.FINCRA, PSPType.STRIPE],
        "central_africa": [PSPType.MTN_MOMO, PSPType.ORANGE_MONEY, PSPType.KORA],
        "international": [PSPType.STRIPE, PSPType.FINCRA],
    }

    @classmethod
    def select_psp(
        cls,
        currency: str,
        method: str = "mobile_money",
        region: str = "west_africa",
        amount: Decimal | None = None,
    ) -> PSPType:
        currency = currency.upper()
        method = method.lower()

        if currency not in cls.CURRENCY_PSP_MAP:
            raise CurrencyNotSupportedError(f"Currency {currency} not supported by any PSP")

        available = cls.CURRENCY_PSP_MAP[currency]

        # Filter by method if specified
        if method in cls.METHOD_PSP_MAP:
            method_psps = cls.METHOD_PSP_MAP[method]
            available = [psp for psp in available if psp in method_psps]

        priority = cls.REGION_PSP_PRIORITY.get(region, cls.REGION_PSP_PRIORITY["international"])
        candidates = [psp for psp in priority if psp in available]

        if not candidates:
            raise PaymentError(f"No PSP available for {currency} in {region} with method {method}")

        # Check API key availability
        for psp in candidates:
            if cls._has_credentials(psp):
                return psp

        # CORRECTION (régression) : en développement (aucun identifiant PSP
        # configuré), cette méthode levait systématiquement PaymentError AVANT
        # même d'atteindre le fallback de simulation présent dans
        # payment_service._call_kora() / _call_fincra() / etc. Résultat : le
        # "Quick Start" du README (curl sans clés PSP réelles) échouait
        # immédiatement. En dev/staging, on retourne le PSP prioritaire pour
        # que le fallback de simulation en aval puisse s'exécuter normalement.
        if not settings.is_production:
            return candidates[0]

        raise PaymentError(f"No PSP with valid credentials for {currency}")

    @classmethod
    def _has_credentials(cls, psp: PSPType) -> bool:
        settings = get_settings()
        cred_map = {
            PSPType.KORA: bool(settings.kora_api_key and settings.kora_secret_key),
            PSPType.FINCRA: bool(settings.fincra_api_key and settings.fincra_secret_key),
            PSPType.FLUTTERWAVE: bool(settings.flutterwave_public_key and settings.flutterwave_secret_key),
            PSPType.STRIPE: bool(settings.stripe_publishable_key and settings.stripe_secret_key),
            # CORRECTION (régression) : payment_service._call_psp_api() route TOUJOURS
            # MTN_MOMO et ORANGE_MONEY vers _call_kora(), qui exige spécifiquement
            # kora_secret_key. L'ancienne vérification acceptait
            # "kora_api_key OR flutterwave_public_key" — si seules des clés
            # Flutterwave étaient configurées (pas Kora), le routeur choisissait
            # quand même MTN_MOMO en le croyant utilisable, puis _call_kora()
            # basculait silencieusement en simulation faute de kora_secret_key,
            # alors que des identifiants Flutterwave réels et valides existaient.
            # La vérification reflète maintenant ce qui est réellement appelé.
            PSPType.MTN_MOMO: bool(settings.kora_api_key and settings.kora_secret_key),
            PSPType.ORANGE_MONEY: bool(settings.kora_api_key and settings.kora_secret_key),
        }
        return bool(cred_map.get(psp))


psp_router = PSPRouter()
